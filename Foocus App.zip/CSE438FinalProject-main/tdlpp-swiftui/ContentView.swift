//
//  ContentView.swift
//  tdlpp-swiftui
//
//  Created by Bruce Li on 11/15/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TaskList()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
