CSE438 Final Project:
App Name: TDLPP

Features:
Add/Edit/Delete Tasks and all fields in the tasks
Setting label for each task
Text for description
Add an image for each task (Image will be stored in our database)
Customize color theme for each task (Notice: We give user free & the right to choose their ideal colors. 
However, light colors may affect readability)
Adding a file to each task which can preview/export that file for convenience (Notice: file can be selected from the local storage/ iCloud.)
Setting priority of task 
Sortable based on priority / Timeline (Todo/doing/done)
Group by labels / priority / Timeline
Searching for specific task with the name
Set due date for each task
Realtime Progress bar showing time remaining for each task before the due date

Framework: Swift-UI
Database: SQLite

